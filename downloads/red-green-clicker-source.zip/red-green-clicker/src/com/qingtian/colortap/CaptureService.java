package com.qingtian.colortap;

import android.app.*;
import android.content.*;
import android.content.res.Configuration;
import android.graphics.PixelFormat;
import android.hardware.display.*;
import android.media.*;
import android.media.projection.*;
import android.os.*;
import android.util.DisplayMetrics;
import java.nio.ByteBuffer;

public class CaptureService extends Service {
    public static volatile CaptureService instance;
    public static volatile String status="采集未开启";
    private final Handler main=new Handler(Looper.getMainLooper());
    private HandlerThread thread;
    private Handler worker;
    private MediaProjection projection;
    private VirtualDisplay display;
    private ImageReader reader;
    // Worker-thread only: retain one most-recent frame, including while paused.
    // This lets Start inspect a static red screen without waiting for it to redraw.
    private Image latestImage,lastProcessedImage;
    private int lastProcessedGeneration=-1;
    private int width,height,mx,my,tx,ty,radius;
    private volatile int generation;
    private volatile boolean watching,pending,cooling,closing;
    private boolean repeat;
    private volatile ColorDetector detector;
    private long lastUi;
    private int clicks;
    private final MediaProjection.Callback projectionCallback=new MediaProjection.Callback() {
        public void onStop() { if(!closing) { pauseHere("屏幕采集已被系统停止"); stopSelf(); } }
        // Public API 34 callback. Intentionally no @Override when compiling with API 30.
        public void onCapturedContentResize(int w,int h) {
            if(!closing && (w!=width || h!=height)) { pauseHere("采集范围变化，请重新授权整个屏幕"); stopSelf(); }
        }
    };
    public IBinder onBind(Intent i) { return null; }
    public void onCreate() { super.onCreate(); instance=this; }
    public int onStartCommand(Intent intent,int flags,int startId) {
        if(intent==null || "STOP".equals(intent.getAction())) { pauseHere("采集已关闭"); stopSelf(); return START_NOT_STICKY; }
        if(projection!=null)return START_NOT_STICKY;
        try {
            NotificationManager nm=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);
            nm.createNotificationChannel(new NotificationChannel("capture","屏幕颜色识别",NotificationManager.IMPORTANCE_LOW));
            PendingIntent stop=PendingIntent.getService(this,1,new Intent(this,CaptureService.class).setAction("STOP"),PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
            PendingIntent open=PendingIntent.getActivity(this,2,new Intent(this,MainActivity.class),PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
            Notification n=new Notification.Builder(this,"capture").setSmallIcon(R.drawable.icon).setContentTitle("红绿快点 · 本机屏幕采集")
                .setContentText("由悬浮条开始/暂停；点“停止采集”立即关闭").setContentIntent(open).setOngoing(true)
                .addAction(new Notification.Action.Builder(null,"停止采集",stop).build()).build();
            startForeground(17,n);
            DisplayMetrics m=Prefs.screen(this); width=m.widthPixels; height=m.heightPixels;
            thread=new HandlerThread("color-fast-path",android.os.Process.THREAD_PRIORITY_DISPLAY); thread.start(); worker=new Handler(thread.getLooper());
            projection=((MediaProjectionManager)getSystemService(MEDIA_PROJECTION_SERVICE)).getMediaProjection(intent.getIntExtra("code",0),(Intent)intent.getParcelableExtra("token"));
            if(projection==null)throw new IllegalStateException("授权无效");
            projection.registerCallback(projectionCallback,main);
            reader=ImageReader.newInstance(width,height,PixelFormat.RGBA_8888,3);
            reader.setOnImageAvailableListener(this::frame,worker);
            display=projection.createVirtualDisplay("ColorTap",width,height,getResources().getConfiguration().densityDpi,DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,reader.getSurface(),null,worker);
            setStatus("已就绪 · 选好两个点，再按开始");
        } catch(Exception e) { setStatus("采集失败："+e.getClass().getSimpleName()+"；请回应用重新授权"); stopSelf(); }
        return START_NOT_STICKY;
    }
    public boolean busy() { return watching || pending || cooling; }
    public synchronized void begin() {
        if(closing || reader==null) { setStatus("采集尚未就绪"); return; }
        DisplayMetrics m=Prefs.screen(this);
        if(width!=m.widthPixels || height!=m.heightPixels) { setStatus("屏幕已旋转，请重新开启采集并选点"); stopSelf(); return; }
        if(!Prefs.configured(this,width,height)) { setStatus("请先分别选监测点和点击点"); return; }
        if(TapService.instance==null) { setStatus("无障碍服务未连接"); return; }
        if(TapService.instance.blocksConfiguredPoints()) { setStatus("控制条盖住选点，请拖动移开"); return; }
        android.content.SharedPreferences p=Prefs.get(this);
        mx=p.getInt("mx",-1); my=p.getInt("my",-1); tx=p.getInt("tx",-1); ty=p.getInt("ty",-1);
        if(mx>=width || my>=height || tx>=width || ty>=height) { setStatus("选点超出屏幕，请重新选点"); return; }
        radius=p.getBoolean("sample",true)?1:0; repeat=p.getBoolean("repeat",false);
        generation++; pending=false; cooling=false; detector=new ColorDetector(p.getInt("frames",1)); watching=true;
        setStatus("监测中 · 等待红色 → 绿色");
        worker.post(()->{ if(!closing && watching)frame(reader); });
    }
    public static void pause() { CaptureService c=instance; if(c!=null)c.pauseHere("已暂停 · 按开始重新等待红色"); }
    private synchronized void pauseHere(String s) { watching=false; pending=false; cooling=false; generation++; setStatus(s); }
    public static void stop(Context c) { CaptureService s=instance; if(s!=null)s.pauseHere("采集已关闭"); c.stopService(new Intent(c,CaptureService.class)); }
    public synchronized boolean canDeliver(int g) { return instance==this && !closing && pending && generation==g; }
    public synchronized void failed(int g,String s) { if(generation==g)pauseHere(s); }
    public synchronized void delivered(int g,boolean success) {
        if(!canDeliver(g))return;
        pending=false;
        if(!success) { pauseHere("点击被系统取消，已暂停"); return; }
        clicks++;
        if(!repeat) { setStatus("已点击 "+clicks+" 次 · 本轮完成"); return; }
        cooling=true;
        setStatus("已点击 "+clicks+" 次 · 等待重新变红");
        // Cooldown never delays the first tap. A NEW red must be observed after it.
        main.postDelayed(()->{ synchronized(CaptureService.this) {
            if(instance!=this || closing || generation!=g)return;
            detector=new ColorDetector(Prefs.get(this).getInt("frames",1)); cooling=false; watching=true;
            setStatus("循环监测 · 等待新的红色 → 绿色");
            worker.post(()->{ if(!closing && watching)frame(reader); });
        }},300);
    }
    private void acquireFrame(ImageReader source) {
        if(closing || source==null)return;
        Image fresh=source.acquireLatestImage();
        if(fresh!=null) {
            if(latestImage!=null)latestImage.close();
            latestImage=fresh;
        }
    }
    private void frame(ImageReader source) {
        try {
            acquireFrame(source);
            if(latestImage!=null)processFrame(latestImage);
        } catch(IllegalStateException e) { if(!closing)pauseHere("采集通道中断，请重新授权"); }
        catch(RuntimeException e) { if(!closing)pauseHere("识别异常，已暂停："+e.getClass().getSimpleName()); }
    }
    private void processFrame(Image image) {
        try {
            if(image==null || !watching || closing)return;
            int g=generation;
            ColorDetector d=detector;
            if(d==null || (image==lastProcessedImage && lastProcessedGeneration==g))return;
            lastProcessedImage=image; lastProcessedGeneration=g;
            if(image.getWidth()!=width || image.getHeight()!=height) { pauseHere("采集尺寸变化，请重新授权整个屏幕"); return; }
            long t=System.nanoTime();
            Image.Plane p=image.getPlanes()[0]; ByteBuffer b=p.getBuffer();
            int stride=p.getPixelStride(),row=p.getRowStride();
            int r=0,green=0,blue=0,n=0;
            for(int y=Math.max(0,my-radius);y<=Math.min(height-1,my+radius);y++) for(int x=Math.max(0,mx-radius);x<=Math.min(width-1,mx+radius);x++) {
                int at=y*row+x*stride;
                if(stride<3 || at+2>=b.limit()) { pauseHere("不支持此设备的采集像素格式"); return; }
                r+=b.get(at)&255; green+=b.get(at+1)&255; blue+=b.get(at+2)&255; n++;
            }
            if(n==0)return;
            int color=ColorDetector.classify(r/n,green/n,blue/n);
            boolean trigger=d.accept(color);
            if(trigger) {
                synchronized(this) {
                    if(!watching || generation!=g || d!=detector)return;
                    watching=false; pending=true;
                }
                TapService tap=TapService.instance;
                if(tap==null) { failed(g,"无障碍已断开，监测暂停"); return; }
                // Post the gesture BEFORE low-priority UI / telemetry.
                tap.tap(this,g,tx,ty);
                long us=(System.nanoTime()-t)/1000;
                setStatus("已识别绿色，提交点击 · 识别计算 "+us+" μs");
            } else if(t-lastUi>250000000L && watching && g==generation) {
                lastUi=t;
                setStatus((d.isArmed()?"已见红 · 等待绿色":"监测中 · 等待红色")+"\nRGB "+r/n+", "+green/n+", "+blue/n);
            }
        } catch(IllegalStateException e) { if(!closing)pauseHere("采集通道中断，请重新授权"); }
        catch(RuntimeException e) { if(!closing)pauseHere("识别异常，已暂停："+e.getClass().getSimpleName()); }
    }
    private void setStatus(String s) { status=s; TapService tap=TapService.instance; if(tap!=null)tap.update(s); }
    public void onConfigurationChanged(Configuration c) { super.onConfigurationChanged(c); DisplayMetrics m=Prefs.screen(this); if(m.widthPixels!=width || m.heightPixels!=height) { pauseHere("屏幕已旋转，请重新开启采集并选点"); stopSelf(); } }
    public void onDestroy() {
        closing=true; watching=false; pending=false; cooling=false; generation++;
        main.removeCallbacksAndMessages(null);
        if(reader!=null)reader.setOnImageAvailableListener(null,null);
        if(display!=null)display.release();
        // Release ImageReader after its current callback has finished.
        ImageReader old=reader; reader=null;
        if(worker!=null)worker.post(()->{ if(latestImage!=null) { latestImage.close(); latestImage=null; lastProcessedImage=null; } if(old!=null)old.close(); });
        else if(old!=null)old.close();
        if(projection!=null) { projection.unregisterCallback(projectionCallback); projection.stop(); }
        if(thread!=null)thread.quitSafely();
        if(instance==this)instance=null;
        stopForeground(true);
        if(!status.contains("失败") && !status.contains("旋转") && !status.contains("系统停止"))setStatus("采集已关闭");
        else if(TapService.instance!=null)TapService.instance.update(status);
        super.onDestroy();
    }
}
