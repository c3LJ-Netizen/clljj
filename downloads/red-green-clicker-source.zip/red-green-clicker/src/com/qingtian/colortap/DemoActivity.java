package com.qingtian.colortap;

import android.app.Activity;
import android.os.*;
import android.graphics.Color;
import android.widget.*;
import android.view.*;

public class DemoActivity extends Activity {
    private final Handler main=new Handler(Looper.getMainLooper());
    private TextView target,results;
    private int hits;
    private long greenTime;
    public void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout root=new LinearLayout(this); root.setOrientation(1); root.setPadding(20,20,20,20); root.setBackgroundColor(0xfff3f7f5); setContentView(root);
        TextView help=new TextView(this); help.setText("红 → 绿实测\n先点“设置测试坐标”，移开悬浮条，按悬浮条“开始”，再点“3秒后变绿”。这能测到本机的变色到点击耗时。"); help.setTextSize(17); help.setTextColor(0xff173f3e); root.addView(help);
        target=new TextView(this); target.setGravity(Gravity.CENTER); target.setText("RED\n等待变绿"); target.setTextColor(Color.WHITE); target.setTextSize(28); target.setBackgroundColor(0xffd92f3f);
        LinearLayout.LayoutParams tp=new LinearLayout.LayoutParams(-1,0,1); tp.topMargin=20; tp.bottomMargin=20; root.addView(target,tp);
        results=new TextView(this); results.setText("尚未点击"); results.setTextSize(18); results.setTextColor(0xff173f3e); root.addView(results);
        target.setOnClickListener(v->{ if(greenTime==0) { results.setText("当前为红色，忽略此次手动点击"); return; } long ms=(System.nanoTime()-greenTime)/1000000; hits++; results.setText("收到点击 "+hits+" 次 · 变色后 "+ms+" ms\n包含画面提交、采集与系统手势；仅供本机参考"); greenTime=0; });
        button(root,"设置测试坐标",()->{
            CaptureService.pause(); int[] p=new int[2]; target.getLocationOnScreen(p);
            int x=p[0]+target.getWidth()/5,y=p[1]+target.getHeight()*3/4;
            Prefs.point(this,true,x,y); Prefs.point(this,false,x,y);
            if(TapService.instance!=null) { TapService.instance.showPanel(); TapService.instance.update("测试点："+x+", "+y+"\n移开控制条，再按开始"); }
            Toast.makeText(this,"两个坐标已设为色块内空白处，请移开悬浮条",Toast.LENGTH_LONG).show();
        });
        button(root,"3 秒后变绿",()->{
            main.removeCallbacksAndMessages(null); greenTime=0;
            target.setBackgroundColor(0xffd92f3f); target.setText("RED\n3 秒后变绿"); results.setText("确认悬浮条显示“监测中 / 已见红”");
            main.postDelayed(()->{ target.setBackgroundColor(0xff14c969); target.setText("GREEN\n等待自动点击"); greenTime=System.nanoTime(); },3000);
        });
        button(root,"返回设置",this::finish);
    }
    private void button(LinearLayout root,String s,Runnable r) { Button b=new Button(this); b.setText(s); root.addView(b); b.setOnClickListener(v->r.run()); }
    protected void onPause() { main.removeCallbacksAndMessages(null); super.onPause(); }
    protected void onDestroy() { main.removeCallbacksAndMessages(null); super.onDestroy(); }
}
