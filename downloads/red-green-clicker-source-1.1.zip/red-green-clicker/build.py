"""Dependency-free Android build. Python 3, JDK 11+, Android platform 30+, Build Tools 35.
Set JAVA_HOME, ANDROID_JAR, ANDROID_BUILD_TOOLS. Signing material stays outside source.
"""
import os, pathlib, subprocess, zipfile, shutil, xml.etree.ElementTree as ET
ROOT=pathlib.Path(__file__).resolve().parent
BUILD=pathlib.Path(os.environ.get('COLOR_TAP_BUILD', str(ROOT.parent.parent/'work'/'color-tap-build'))).resolve()
JAVA=pathlib.Path(os.environ['JAVA_HOME'])/'bin'
SDK=pathlib.Path(os.environ['ANDROID_BUILD_TOOLS'])
ANDROID=pathlib.Path(os.environ['ANDROID_JAR'])
def run(*args):
    print('>', ' '.join(str(x) for x in args), flush=True)
    subprocess.run([str(x) for x in args],check=True)
def j(name): return JAVA/(name+('.exe' if os.name=='nt' else ''))
def tool(name): return SDK/(name+('.exe' if os.name=='nt' else ''))
BUILD.mkdir(parents=True,exist_ok=True)
for d in ['generated','classes','dex','tests']:
    p=BUILD/d
    if p.resolve().parent != BUILD: raise RuntimeError('Build child resolves outside intended build directory: '+str(p))
    if p.exists(): shutil.rmtree(p)
    p.mkdir()
pure=[ROOT/'src/com/qingtian/colortap'/name for name in ['ColorDetector.java','PixelSampler.java','TimingTrace.java','TraceHub.java','LatencyStats.java']]
tests=sorted((ROOT/'test').glob('*Test.java'))
run(j('javac'),'-encoding','UTF-8','-source','8','-target','8','-d',BUILD/'tests',*pure,*tests)
for test in tests: run(j('java'),'-cp',BUILD/'tests',test.stem)
run(tool('aapt2'),'compile','--dir',ROOT/'res','-o',BUILD/'resources.zip')
run(tool('aapt2'),'link','-o',BUILD/'resource.apk','--manifest',ROOT/'AndroidManifest.xml','-I',ANDROID,'--java',BUILD/'generated',BUILD/'resources.zip')
files=list((ROOT/'src').rglob('*.java'))+list((BUILD/'generated').rglob('*.java'))
args=BUILD/'javac.args'
args.write_text('\n'.join('"'+str(x).replace('\\','/')+'"' for x in files),encoding='utf-8')
run(j('javac'),'-encoding','UTF-8','-source','8','-target','8','-classpath',ANDROID,'-d',BUILD/'classes','@'+str(args))
run(j('jar'),'cf',BUILD/'classes.jar','-C',BUILD/'classes','.')
run(j('java'),'-cp',SDK/'lib/d8.jar','com.android.tools.r8.D8','--release','--lib',ANDROID,'--min-api','26','--output',BUILD/'dex',BUILD/'classes.jar')
shutil.copyfile(BUILD/'resource.apk',BUILD/'unsigned.apk')
with zipfile.ZipFile(BUILD/'unsigned.apk','a') as z:
    for dex in (BUILD/'dex').glob('*.dex'): z.write(dex,dex.name,compress_type=zipfile.ZIP_DEFLATED)
run(tool('zipalign'),'-f','-p','4',BUILD/'unsigned.apk',BUILD/'aligned.apk')
key=BUILD/'release.keystore'
if not key.exists():
    run(j('keytool'),'-genkeypair','-keystore',key,'-storepass','android','-keypass','android','-alias','colortap','-keyalg','RSA','-keysize','2048','-validity','10000','-dname','CN=ColorTap Personal Build, O=Qingtian, C=CN')
version=ET.parse(ROOT/'AndroidManifest.xml').getroot().attrib['{http://schemas.android.com/apk/res/android}versionName']
out=ROOT.parent/('red-green-clicker-'+version+'.apk')
run(j('java'),'-jar',SDK/'lib/apksigner.jar','sign','--ks',key,'--ks-key-alias','colortap','--ks-pass','pass:android','--key-pass','pass:android','--out',out,BUILD/'aligned.apk')
run(j('java'),'-jar',SDK/'lib/apksigner.jar','verify','--verbose','--print-certs',out)
run(tool('aapt'),'dump','badging',out)
print('APK:',out,'bytes:',out.stat().st_size,flush=True)
