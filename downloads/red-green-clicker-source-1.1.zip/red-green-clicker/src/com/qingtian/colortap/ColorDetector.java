package com.qingtian.colortap;

/** Pure Java state machine. A fresh red observation must precede each green trigger. */
public final class ColorDetector {
    public static final int OTHER=0, RED=1, GREEN=2;
    private final int confirmation;
    private boolean armed;
    private boolean fired;
    private int greens;
    public ColorDetector(int confirmation) { this.confirmation=Math.max(1, confirmation); }
    public static int classify(int r, int g, int b) {
        int max=Math.max(r,Math.max(g,b)), min=Math.min(r,Math.min(g,b));
        int d=max-min;
        if(max<64 || d<max*0.38f) return OTHER;
        float hue;
        if(max==r) hue=60f*(g-b)/d;
        else if(max==g) hue=120f+60f*(b-r)/d;
        else hue=240f+60f*(r-g)/d;
        if(hue<0) hue+=360;
        if(hue<=25 || hue>=340) return RED;
        if(hue>=70 && hue<=170) return GREEN;
        return OTHER;
    }
    public boolean accept(int color) {
        if(fired) return false;
        if(color==RED) { armed=true; greens=0; }
        else if(color==GREEN && armed) {
            if(++greens>=confirmation) { fired=true; return true; }
        } else greens=0;
        return false;
    }
    public boolean isArmed() { return armed; }
}
