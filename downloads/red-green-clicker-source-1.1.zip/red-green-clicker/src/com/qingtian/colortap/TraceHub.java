package com.qingtian.colortap;

/** In-memory diagnostics only. No screen recording, network or persistent logging. */
public final class TraceHub {
    public static volatile TimingTrace latest;
    public static volatile long demoSourceNs;
    private TraceHub() { }
    public static TimingTrace forDemo(long source) {
        TimingTrace t=latest;
        return source>0 && t!=null && t.sourceRequestedNs==source && t.dispatchNs>0 && !t.rejected && !t.cancelled ? t : null;
    }
}
