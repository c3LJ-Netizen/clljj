package com.qingtian.colortap;

import android.app.*;
import android.content.*;
import android.content.res.Configuration;
import android.graphics.PixelFormat;
import android.hardware.display.*;
import android.media.*;
import android.media.projection.*;
import android.os.*;
import android.util.DisplayMetrics;

public class CaptureService extends Service {
    public static volatile CaptureService instance;
    public static volatile String status="采集未开启";
    private final Handler main=new Handler(Looper.getMainLooper());
    private HandlerThread thread;
    private Handler worker;
    private MediaProjection projection;
    private VirtualDisplay display;
    private ImageReader reader;
    // Worker-thread only: retain one most-recent frame, including while paused.
    // This lets Start inspect a static red screen without waiting for it to redraw.
    private Image latestImage,lastProcessedImage;
    private int lastProcessedGeneration=-1;
    private int width,height,captureWidth,captureHeight,scaleDivisor,mx,my,tx,ty,sampleX,sampleY,radius;
    private volatile int generation;
    private volatile boolean watching,pending,cooling,closing,redSeen;
    private boolean repeat,direct;
    private volatile String profile="";
    private volatile ColorDetector detector;
    private long latestFrameCallbackNs,latestFrameReadyNs;
    private int clicks;
    private final MediaProjection.Callback projectionCallback=new MediaProjection.Callback() {
        public void onStop() { if(!closing) { pauseHere("屏幕采集已被系统停止"); stopSelf(); } }
        // Public API 34 callback. Intentionally no @Override when compiling with API 30.
        public void onCapturedContentResize(int w,int h) {
            if(!closing && (w!=width || h!=height)) { pauseHere("采集范围变化，请重新授权整个屏幕"); stopSelf(); }
        }
    };
    public IBinder onBind(Intent i) { return null; }
    public void onCreate() { super.onCreate(); instance=this; }
    public int onStartCommand(Intent intent,int flags,int startId) {
        if(intent==null || "STOP".equals(intent.getAction())) { pauseHere("采集已关闭"); stopSelf(); return START_NOT_STICKY; }
        if(projection!=null)return START_NOT_STICKY;
        try {
            NotificationManager nm=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);
            nm.createNotificationChannel(new NotificationChannel("capture","屏幕颜色识别",NotificationManager.IMPORTANCE_LOW));
            PendingIntent stop=PendingIntent.getService(this,1,new Intent(this,CaptureService.class).setAction("STOP"),PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
            PendingIntent open=PendingIntent.getActivity(this,2,new Intent(this,MainActivity.class),PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
            Notification n=new Notification.Builder(this,"capture").setSmallIcon(R.drawable.icon).setContentTitle("红绿快点 · 本机屏幕采集")
                .setContentText("由悬浮条开始/暂停；点“停止采集”立即关闭").setContentIntent(open).setOngoing(true)
                .addAction(new Notification.Action.Builder(null,"停止采集",stop).build()).build();
            startForeground(17,n);
            DisplayMetrics m=Prefs.screen(this); width=m.widthPixels; height=m.heightPixels;
            scaleDivisor=PixelSampler.divisor(width,height,Prefs.get(this).getInt("divisor",2));
            captureWidth=width/scaleDivisor; captureHeight=height/scaleDivisor;
            thread=new HandlerThread("color-fast-path",android.os.Process.THREAD_PRIORITY_DISPLAY); thread.start(); worker=new Handler(thread.getLooper());
            projection=((MediaProjectionManager)getSystemService(MEDIA_PROJECTION_SERVICE)).getMediaProjection(intent.getIntExtra("code",0),(Intent)intent.getParcelableExtra("token"));
            if(projection==null)throw new IllegalStateException("授权无效");
            projection.registerCallback(projectionCallback,main);
            reader=ImageReader.newInstance(captureWidth,captureHeight,PixelFormat.RGBA_8888,3);
            reader.setOnImageAvailableListener(this::frame,worker);
            display=projection.createVirtualDisplay("ColorTap",captureWidth,captureHeight,Math.max(1,getResources().getConfiguration().densityDpi/scaleDivisor),DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,reader.getSurface(),null,worker);
            setStatus("已就绪 · 采集 "+captureWidth+" × "+captureHeight+"\n选好两个点，再按开始");
        } catch(Exception e) { setStatus("采集失败："+e.getClass().getSimpleName()+"；请回应用重新授权"); stopSelf(); }
        return START_NOT_STICKY;
    }
    public boolean busy() { return watching || pending || cooling; }
    public boolean isArmed() { return watching && redSeen; }
    public String profile() { return profile; }
    public synchronized boolean begin() { return begin(false); }
    public synchronized boolean beginTest() { return begin(true); }
    private boolean begin(boolean test) {
        if(closing || reader==null) { setStatus("采集尚未就绪"); return false; }
        DisplayMetrics m=Prefs.screen(this);
        if(width!=m.widthPixels || height!=m.heightPixels) { setStatus("屏幕已旋转，请重新开启采集并选点"); stopSelf(); return false; }
        if(!Prefs.configured(this,width,height)) { setStatus("请先分别选监测点和点击点"); return false; }
        if(TapService.instance==null) { setStatus("无障碍服务未连接"); return false; }
        if(TapService.instance.blocksConfiguredPoints()) { setStatus("控制条盖住选点，请拖动移开"); return false; }
        android.content.SharedPreferences p=Prefs.get(this);
        mx=p.getInt("mx",-1); my=p.getInt("my",-1); tx=p.getInt("tx",-1); ty=p.getInt("ty",-1);
        if(mx>=width || my>=height || tx>=width || ty>=height) { setStatus("选点超出屏幕，请重新选点"); return false; }
        sampleX=PixelSampler.map(mx,width,captureWidth); sampleY=PixelSampler.map(my,height,captureHeight);
        radius=p.getBoolean("sample",true)?1:0; repeat=!test && p.getBoolean("repeat",false); direct=p.getBoolean("direct",true);
        profile=(100/scaleDivisor)+"%采集 · "+(direct?"直达":"兼容")+" · "+p.getInt("frames",1)+"帧";
        TapService.instance.prepare(tx,ty);
        generation++; pending=false; cooling=false; redSeen=false; detector=new ColorDetector(p.getInt("frames",1)); watching=true;
        setStatus("监测中 · 等待红色 → 绿色\n"+profile);
        worker.post(()->{ if(!closing && watching)frame(reader); });
        return true;
    }
    public static void pause() { CaptureService c=instance; if(c!=null)c.pauseHere("已暂停 · 按开始重新等待红色"); }
    private synchronized void pauseHere(String s) { watching=false; pending=false; cooling=false; generation++; setStatus(s); }
    public static void stop(Context c) { CaptureService s=instance; if(s!=null)s.pauseHere("采集已关闭"); c.stopService(new Intent(c,CaptureService.class)); }
    public synchronized boolean canDeliver(int g) { return instance==this && !closing && pending && generation==g; }
    public synchronized void failed(int g,String s) { if(generation==g)pauseHere(s); }
    public synchronized void delivered(int g,boolean success) {
        if(!canDeliver(g))return;
        pending=false;
        if(!success) { pauseHere("点击被系统取消，已暂停"); return; }
        clicks++;
        if(!repeat) { setStatus("已点击 "+clicks+" 次 · 本轮完成"); return; }
        cooling=true;
        setStatus("已点击 "+clicks+" 次 · 等待重新变红");
        // Cooldown never delays the first tap. A NEW red must be observed after it.
        main.postDelayed(()->{ synchronized(CaptureService.this) {
            if(instance!=this || closing || generation!=g)return;
            detector=new ColorDetector(Prefs.get(this).getInt("frames",1)); cooling=false; redSeen=false; watching=true;
            setStatus("循环监测 · 等待新的红色 → 绿色");
            worker.post(()->{ if(!closing && watching)frame(reader); });
        }},300);
    }
    private void acquireFrame(ImageReader source,long callbackNs) {
        if(closing || source==null)return;
        Image fresh=source.acquireLatestImage();
        if(fresh!=null) {
            long readyNs=System.nanoTime();
            if(latestImage!=null)latestImage.close();
            latestImage=fresh;
            latestFrameCallbackNs=callbackNs;
            latestFrameReadyNs=readyNs;
        }
    }
    private void frame(ImageReader source) {
        long callbackNs=System.nanoTime();
        try {
            acquireFrame(source,callbackNs);
            if(latestImage!=null)processFrame(latestImage);
        } catch(IllegalStateException e) { if(!closing)pauseHere("采集通道中断，请重新授权"); }
        catch(RuntimeException e) { if(!closing)pauseHere("识别异常，已暂停："+e.getClass().getSimpleName()); }
    }
    private void processFrame(Image image) {
        try {
            if(image==null)return;
            final int g,sx,sy,sr,monitorX,monitorY,tapX,tapY;
            final ColorDetector d;
            final boolean runDirect;
            final String runProfile;
            synchronized(this) {
                if(!watching || closing)return;
                g=generation; d=detector;
                if(d==null || (image==lastProcessedImage && lastProcessedGeneration==g))return;
                lastProcessedImage=image; lastProcessedGeneration=g;
                sx=sampleX; sy=sampleY; sr=radius; monitorX=mx; monitorY=my; tapX=tx; tapY=ty;
                runDirect=direct; runProfile=profile;
            }
            if(image.getWidth()!=captureWidth || image.getHeight()!=captureHeight) { pauseHere("采集尺寸变化，请重新授权整个屏幕"); return; }
            Image.Plane p=image.getPlanes()[0];
            int rgb=PixelSampler.rgb(p.getBuffer(),captureWidth,captureHeight,p.getRowStride(),p.getPixelStride(),sx,sy,sr);
            if(rgb<0) { pauseHere("不支持此设备的采集像素格式"); return; }
            int color=ColorDetector.classify((rgb>>16)&255,(rgb>>8)&255,rgb&255);
            boolean trigger=d.accept(color);
            if(trigger) {
                synchronized(this) {
                    if(!watching || generation!=g || d!=detector)return;
                    watching=false; pending=true;
                }
                TapService tap=TapService.instance;
                if(tap==null) { failed(g,"无障碍已断开，监测暂停"); return; }
                TimingTrace trace=new TimingTrace(TraceHub.demoSourceNs,latestFrameCallbackNs,latestFrameReadyNs,System.nanoTime(),runProfile);
                TraceHub.latest=trace;
                // Default fast path submits on this worker; no main-queue hop or View access.
                tap.tap(this,g,monitorX,monitorY,tapX,tapY,runDirect,trace);
            } else if(d.isArmed() && !redSeen) {
                synchronized(this) {
                    if(!watching || g!=generation || d!=detector)return;
                    redSeen=true;
                    setStatus("已见红 · 等待绿色\n"+runProfile);
                }
            }
        } catch(IllegalStateException e) { if(!closing)pauseHere("采集通道中断，请重新授权"); }
        catch(RuntimeException e) { if(!closing)pauseHere("识别异常，已暂停："+e.getClass().getSimpleName()); }
    }
    private void setStatus(String s) { status=s; TapService tap=TapService.instance; if(tap!=null)tap.update(s); }
    public void onConfigurationChanged(Configuration c) { super.onConfigurationChanged(c); DisplayMetrics m=Prefs.screen(this); if(m.widthPixels!=width || m.heightPixels!=height) { pauseHere("屏幕已旋转，请重新开启采集并选点"); stopSelf(); } }
    public void onDestroy() {
        synchronized(this) { closing=true; watching=false; pending=false; cooling=false; generation++; }
        main.removeCallbacksAndMessages(null);
        if(reader!=null)reader.setOnImageAvailableListener(null,null);
        if(display!=null)display.release();
        // Release ImageReader after its current callback has finished.
        ImageReader old=reader; reader=null;
        if(worker!=null)worker.post(()->{ if(latestImage!=null) { latestImage.close(); latestImage=null; lastProcessedImage=null; } if(old!=null)old.close(); });
        else if(old!=null)old.close();
        if(projection!=null) { projection.unregisterCallback(projectionCallback); projection.stop(); }
        if(thread!=null)thread.quitSafely();
        if(instance==this)instance=null;
        stopForeground(true);
        if(!status.contains("失败") && !status.contains("旋转") && !status.contains("系统停止"))setStatus("采集已关闭");
        else if(TapService.instance!=null)TapService.instance.update(status);
        super.onDestroy();
    }
}
