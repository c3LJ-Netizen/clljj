package com.qingtian.colortap;

import java.util.Arrays;

/** One profile per series; keep all successful samples, not only the fastest result. */
public final class LatencyStats {
    private final double[] samples=new double[100];
    private int count;
    public void reset() { count=0; }
    public boolean add(double millis) {
        if(Double.isNaN(millis) || Double.isInfinite(millis) || millis<0 || count==samples.length)return false;
        samples[count++]=millis; return true;
    }
    public int count() { return count; }
    public double percentile(double fraction) {
        if(count==0 || fraction<0 || fraction>1)return -1;
        double[] sorted=Arrays.copyOf(samples,count); Arrays.sort(sorted);
        if(fraction==0.5 && count%2==0)return (sorted[count/2-1]+sorted[count/2])/2;
        return sorted[Math.max(0,(int)Math.ceil(fraction*count)-1)];
    }
    public double min() { return percentile(0); }
    public double median() { return percentile(0.5); }
    public double p95() { return percentile(0.95); }
    public double max() { return percentile(1); }
}
