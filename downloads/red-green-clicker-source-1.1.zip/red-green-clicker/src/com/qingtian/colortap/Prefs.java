package com.qingtian.colortap;
import android.content.Context;
import android.content.SharedPreferences;
import android.util.DisplayMetrics;
import android.view.WindowManager;

final class Prefs {
    static SharedPreferences get(Context c) { return c.getSharedPreferences("settings",Context.MODE_PRIVATE); }
    static DisplayMetrics screen(Context c) {
        DisplayMetrics m=new DisplayMetrics();
        WindowManager wm=(WindowManager)c.getSystemService(Context.WINDOW_SERVICE);
        wm.getDefaultDisplay().getRealMetrics(m);
        if(android.os.Build.VERSION.SDK_INT>=30) {
            android.graphics.Rect bounds=wm.getMaximumWindowMetrics().getBounds();
            m.widthPixels=bounds.width(); m.heightPixels=bounds.height();
        }
        return m;
    }
    static boolean configured(Context c,int w,int h) {
        SharedPreferences p=get(c);
        return p.getInt("mw",0)==w && p.getInt("mh",0)==h && p.getInt("tw",0)==w && p.getInt("th",0)==h
            && p.getInt("mx",-1)>=0 && p.getInt("my",-1)>=0 && p.getInt("tx",-1)>=0 && p.getInt("ty",-1)>=0;
    }
    static void point(Context c,boolean monitor,int x,int y) {
        DisplayMetrics m=screen(c); String k=monitor?"m":"t";
        get(c).edit().putInt(k+"x",x).putInt(k+"y",y).putInt(k+"w",m.widthPixels).putInt(k+"h",m.heightPixels).apply();
    }
}
