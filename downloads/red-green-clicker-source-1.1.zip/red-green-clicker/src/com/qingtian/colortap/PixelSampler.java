package com.qingtian.colortap;

import java.nio.ByteBuffer;

/** Allocation-free sampling and exact-aspect coordinate conversion. */
public final class PixelSampler {
    private PixelSampler() { }
    public static int divisor(int width,int height,int requested) {
        if(width<=0 || height<=0)throw new IllegalArgumentException("screen size");
        if(requested>=4 && width%4==0 && height%4==0)return 4;
        if(requested>=2 && width%2==0 && height%2==0)return 2;
        return 1; // Preserve aspect ratio on unusual odd-sized displays.
    }
    public static int map(int coordinate,int screenExtent,int captureExtent) {
        if(screenExtent<=0 || captureExtent<=0 || coordinate<0 || coordinate>=screenExtent)throw new IllegalArgumentException("coordinate");
        return Math.min(captureExtent-1,(int)(((2L*coordinate+1)*captureExtent)/(2L*screenExtent)));
    }
    public static int rgb(ByteBuffer buffer,int width,int height,int rowStride,int pixelStride,int x,int y,int radius) {
        if(buffer==null || width<=0 || height<=0 || pixelStride<3 || rowStride<(long)width*pixelStride || x<0 || y<0 || x>=width || y>=height || radius<0 || radius>1)return -1;
        int r=0,g=0,b=0,n=0;
        for(int yy=Math.max(0,y-radius);yy<=Math.min(height-1,y+radius);yy++) {
            for(int xx=Math.max(0,x-radius);xx<=Math.min(width-1,x+radius);xx++) {
                long offset=(long)yy*rowStride+(long)xx*pixelStride;
                if(offset+2>=buffer.limit())return -1;
                int at=(int)offset;
                r+=buffer.get(at)&255; g+=buffer.get(at+1)&255; b+=buffer.get(at+2)&255; n++;
            }
        }
        return ((r/n)<<16)|((g/n)<<8)|(b/n);
    }
}
