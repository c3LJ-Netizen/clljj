package com.qingtian.colortap;

import android.accessibilityservice.*;
import android.content.*;
import android.graphics.*;
import android.os.*;
import android.view.*;
import android.view.accessibility.AccessibilityEvent;
import android.widget.*;

public class TapService extends AccessibilityService {
    public static volatile TapService instance;
    private WindowManager wm;
    private LinearLayout panel;
    private View selector;
    private TextView state;
    private Button start;
    private WindowManager.LayoutParams lp;
    private volatile Rect panelBounds;
    private volatile boolean selecting;
    private volatile GestureDescription preparedGesture;
    private volatile int preparedX=-1,preparedY=-1;
    private final Handler main=new Handler(Looper.getMainLooper());
    protected void onServiceConnected() { super.onServiceConnected(); wm=(WindowManager)getSystemService(WINDOW_SERVICE); instance=this; }
    public void onAccessibilityEvent(AccessibilityEvent e) { }
    public void onInterrupt() { CaptureService.pause(); }
    public void onDestroy() { CaptureService.stop(this); removePanel(); instance=null; super.onDestroy(); }
    private int dp(int n) { return (int)(n*getResources().getDisplayMetrics().density+0.5f); }
    public void showPanel() {
        if(Looper.myLooper()!=Looper.getMainLooper()) { main.post(this::showPanel); return; }
        if(panel!=null)return;
        panel=new LinearLayout(this); panel.setOrientation(1); panel.setPadding(dp(10),dp(5),dp(10),dp(8)); panel.setBackgroundColor(0xf510282b); panel.setElevation(dp(8));
        TextView drag=new TextView(this); drag.setText("红绿快点　↕ 拖动移开监测区域"); drag.setTextColor(0xff65edad); drag.setTextSize(13); drag.setPadding(0,dp(10),0,dp(10)); panel.addView(drag);
        state=new TextView(this); state.setTextColor(Color.WHITE); state.setTextSize(12); panel.addView(state);
        LinearLayout row=new LinearLayout(this); panel.addView(row);
        addButton(row,"选监测点",()->select(true)); addButton(row,"选点击点",()->select(false));
        LinearLayout row2=new LinearLayout(this); panel.addView(row2);
        start=addButton(row2,"开始",()->{
            CaptureService c=CaptureService.instance;
            if(c==null) { toast("请返回应用开启屏幕采集"); return; }
            if(c.busy()) CaptureService.pause(); else c.begin();
        });
        addButton(row2,"停止",()->{ CaptureService.stop(this); update("采集已关闭"); });
        addButton(row2,"收起",()->{ CaptureService.stop(this); removePanel(); });
        lp=new WindowManager.LayoutParams(dp(278),-2,WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL|WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,PixelFormat.TRANSLUCENT);
        lp.gravity=Gravity.TOP|Gravity.LEFT; lp.x=dp(8); lp.y=dp(80);
        drag.setOnTouchListener(new View.OnTouchListener() {
            int x,y; float sx,sy;
            public boolean onTouch(View v,MotionEvent e) {
                if(e.getAction()==MotionEvent.ACTION_DOWN) { CaptureService.pause(); x=lp.x; y=lp.y; sx=e.getRawX(); sy=e.getRawY(); return true; }
                if(e.getAction()==MotionEvent.ACTION_MOVE && panel!=null) {
                    android.util.DisplayMetrics m=Prefs.screen(TapService.this);
                    lp.x=Math.max(0,Math.min(m.widthPixels-panel.getWidth(),x+(int)(e.getRawX()-sx)));
                    lp.y=Math.max(0,Math.min(m.heightPixels-panel.getHeight(),y+(int)(e.getRawY()-sy)));
                    wm.updateViewLayout(panel,lp); panel.post(TapService.this::cachePanelBounds); return true;
                }
                if(e.getAction()==MotionEvent.ACTION_UP) { if(CaptureService.instance!=null && CaptureService.instance.busy() && blocksConfiguredPoints()) { CaptureService.pause(); toast("控制条盖住了选点，监测已暂停"); } return true; }
                return true;
            }
        });
        panel.addOnLayoutChangeListener((v,l,t,r,b,ol,ot,or,ob)->cachePanelBounds());
        try { wm.addView(panel,lp); panel.post(this::cachePanelBounds); update(CaptureService.instance==null?"请先在应用内开启屏幕采集":CaptureService.status); }
        catch(RuntimeException e) { panel=null; toast("无法显示控制条，请重新开启无障碍服务"); }
    }
    private Button addButton(LinearLayout row,String text,Runnable action) {
        Button b=new Button(this); b.setText(text); b.setTextSize(12); b.setAllCaps(false); b.setMinWidth(0); b.setMinimumWidth(0); b.setPadding(0,0,0,0);
        row.addView(b,new LinearLayout.LayoutParams(0,dp(43),1)); b.setOnClickListener(v->action.run()); return b;
    }
    public void update(String s) { main.post(()->{
        if(state!=null && !s.contentEquals(state.getText()))state.setText(s);
        String label=CaptureService.instance!=null && CaptureService.instance.busy()?"暂停":"开始";
        if(start!=null && !label.contentEquals(start.getText()))start.setText(label);
    }); }
    private void cachePanelBounds() {
        if(panel==null || panel.getVisibility()!=View.VISIBLE) { panelBounds=null; return; }
        int[] p=new int[2]; panel.getLocationOnScreen(p);
        panelBounds=new Rect(p[0]-4,p[1]-4,p[0]+panel.getWidth()+4,p[1]+panel.getHeight()+4);
    }
    public boolean blocksConfiguredPoints() {
        cachePanelBounds();
        android.content.SharedPreferences s=Prefs.get(this);
        return blocks(s.getInt("mx",-1),s.getInt("my",-1),s.getInt("tx",-1),s.getInt("ty",-1));
    }
    private boolean blocks(int mx,int my,int tx,int ty) {
        Rect r=panelBounds; // Immutable once published; do not read Views from capture thread.
        return selecting || (r!=null && (r.contains(mx,my) || r.contains(tx,ty)));
    }
    public void prepare(int x,int y) {
        Path p=new Path(); p.moveTo(x,y);
        preparedGesture=new GestureDescription.Builder().addStroke(new GestureDescription.StrokeDescription(p,0,1)).build();
        preparedX=x; preparedY=y;
    }
    private void select(boolean monitor) {
        CaptureService.pause();
        if(selector!=null)return;
        selecting=true; panelBounds=null;
        if(panel!=null)panel.setVisibility(View.GONE);
        selector=new View(this) {
            final Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);
            float x=-1,y=-1;
            protected void onDraw(Canvas c) {
                paint.setColor(0xff65edad); paint.setTextSize(dp(18));
                c.drawText(monitor?"点选要监测的红/绿色块内部":"点选自动点击的位置",dp(18),dp(78),paint);
                paint.setTextSize(dp(13)); c.drawText("松手确认 · 返回键取消",dp(18),dp(104),paint);
                if(x>=0) { paint.setStrokeWidth(dp(1)); c.drawLine(x-dp(20),y,x+dp(20),y,paint); c.drawLine(x,y-dp(20),x,y+dp(20),paint); }
            }
            public boolean onTouchEvent(MotionEvent e) {
                x=e.getX(); y=e.getY(); invalidate();
                if(e.getAction()==MotionEvent.ACTION_UP) {
                    android.util.DisplayMetrics m=Prefs.screen(TapService.this);
                    int px=Math.max(0,Math.min(m.widthPixels-1,Math.round(e.getRawX()))),py=Math.max(0,Math.min(m.heightPixels-1,Math.round(e.getRawY())));
                    Prefs.point(TapService.this,monitor,px,py); dismissSelector();
                    update((monitor?"监测":"点击")+"坐标："+px+", "+py+"\n移开控制条，再按开始");
                }
                return true;
            }
            public boolean onKeyUp(int key,KeyEvent e) { if(key==KeyEvent.KEYCODE_BACK) { dismissSelector(); return true; } return super.onKeyUp(key,e); }
        };
        selector.setFocusableInTouchMode(true);
        WindowManager.LayoutParams slp=new WindowManager.LayoutParams(-1,-1,WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN|WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,PixelFormat.TRANSLUCENT);
        slp.gravity=Gravity.TOP|Gravity.LEFT;
        if(Build.VERSION.SDK_INT>=28)slp.layoutInDisplayCutoutMode=1;
        try { wm.addView(selector,slp); selector.requestFocus(); } catch(RuntimeException e) { selector=null; selecting=false; if(panel!=null) { panel.setVisibility(View.VISIBLE); panel.post(this::cachePanelBounds); } toast("选点窗口无法打开"); }
    }
    private void dismissSelector() { if(selector!=null) { try { wm.removeView(selector); } catch(RuntimeException ignored) { } selector=null; } selecting=false; if(panel!=null) { panel.setVisibility(View.VISIBLE); panel.post(this::cachePanelBounds); } }
    public void removePanel() { dismissSelector(); panelBounds=null; if(panel!=null) { try { wm.removeView(panel); } catch(RuntimeException ignored) { } panel=null; state=null; start=null; } }
    public void tap(CaptureService owner,int generation,int mx,int my,int x,int y,boolean direct,TimingTrace trace) {
        Runnable submit=()->{
            // Serialize validation + submission with Stop. No View reads in this section.
            synchronized(owner) {
                if(instance!=this || !owner.canDeliver(generation))return;
                if(blocks(mx,my,x,y)) { owner.failed(generation,"控制条盖住选点，已暂停"); return; }
                GestureDescription gesture=preparedGesture;
                if(gesture==null || preparedX!=x || preparedY!=y) { owner.failed(generation,"点击坐标已变化，请重新开始"); return; }
                try {
                    trace.dispatchNs=System.nanoTime();
                    boolean accepted=dispatchGesture(gesture,new GestureResultCallback() {
                        public void onCompleted(GestureDescription d) { trace.callbackNs=System.nanoTime(); owner.delivered(generation,true); }
                        public void onCancelled(GestureDescription d) { trace.callbackNs=System.nanoTime(); trace.cancelled=true; owner.delivered(generation,false); }
                    },main);
                    trace.returnNs=System.nanoTime();
                    if(!accepted) { trace.rejected=true; owner.failed(generation,"系统拒绝点击，请检查无障碍权限"); }
                } catch(RuntimeException e) { trace.rejected=true; owner.failed(generation,"点击提交失败，可尝试关闭直达模式："+e.getClass().getSimpleName()); }
            }
        };
        if(direct)submit.run(); else main.post(submit);
    }
    private void toast(String s) { Toast.makeText(this,s,Toast.LENGTH_LONG).show(); }
}
