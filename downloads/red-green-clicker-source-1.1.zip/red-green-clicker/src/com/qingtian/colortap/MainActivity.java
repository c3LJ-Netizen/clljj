package com.qingtian.colortap;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.Color;
import android.media.projection.MediaProjectionManager;
import android.provider.Settings;
import android.view.*;
import android.widget.*;

public class MainActivity extends Activity {
    private TextView status;
    private Spinner frames,scale;
    private CheckBox repeat, sample,direct;
    private final Handler ui=new Handler(Looper.getMainLooper());
    private final Runnable refresh=new Runnable() { public void run() {
        if(status!=null) {
            String s="无障碍："+(TapService.instance!=null?"已连接":"未开启")+"\n屏幕采集："+(CaptureService.instance!=null?CaptureService.status:"未开启")+"\n"+points();
            if(!s.contentEquals(status.getText()))status.setText(s);
        }
        ui.postDelayed(this,700);
    }};
    public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.rgb(16,40,43));
        getWindow().setNavigationBarColor(Color.rgb(16,40,43));
        ScrollView scroll=new ScrollView(this);
        LinearLayout box=new LinearLayout(this); box.setOrientation(1); box.setPadding(28,28,28,40); box.setBackgroundColor(0xfff3f7f5); scroll.addView(box); setContentView(scroll);
        title(box,"红绿快点",30);
        title(box,"RED → GREEN · 1.1 优化版",16);
        text(box,"默认半分辨率采集、识别线程直接提交点击、第一帧绿色触发。减少图像数据和主线程排队。实际收益由手机决定，可在测试页连测 10 次并查看分段耗时。",15);
        status=text(box,"正在检查…",15);
        button(box,"① 开启无障碍点击",()->new AlertDialog.Builder(this).setTitle("允许指定位置点击")
            .setMessage("此功能使用安卓无障碍执行手势。请在下一页找到“红绿快点”并开启；应用不读取页面文字或控件。只有你手动开始监测后才会点击，可随时停止。")
            .setPositiveButton("前往设置",(d,w)->startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))).setNegativeButton("取消",null).show());
        button(box,"② 开启屏幕采集 / 显示控制条",()->requestCapture());
        button(box,"显示悬浮控制条",()->{ if(ready()) TapService.instance.showPanel(); });
        text(box,"操作：进入目标页面 → 用悬浮条选监测点和点击位置 → 按“开始”。监测点应放在色块内部，远离边缘、文字和悬浮条。首次画面为绿色不会触发；必须先看到红色。",15);
        title(box,"识别设置",21);
        scale=new Spinner(this);
        scale.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"半分辨率 · 50% 宽高（默认）","原分辨率 · 100%（小色块/对照）","低分辨率 · 25% 宽高（实验）"}));
        int div=Prefs.get(this).getInt("divisor",2); scale.setSelection(div==1?1:div==4?2:0); box.addView(scale);
        text(box,"半分辨率约为原采集像素数的 1/4。小色块、边缘或文字附近可能取色失准，可切回原分辨率。切换分辨率后需重新授权采集。",13);
        direct=new CheckBox(this); direct.setText("识别线程直接提交点击（默认；关闭为主线程兼容模式）"); direct.setChecked(Prefs.get(this).getBoolean("direct",true)); box.addView(direct);
        frames=new Spinner(this);
        frames.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"极速 · 1 帧绿色即触发","防抖 · 连续 2 帧绿色","稳健 · 连续 3 帧绿色"}));
        frames.setSelection(Math.max(0,Math.min(2,Prefs.get(this).getInt("frames",1)-1))); box.addView(frames);
        sample=new CheckBox(this); sample.setText("采集画面 3 × 3 像素平均（关闭则只读中心 1 像素）"); sample.setChecked(Prefs.get(this).getBoolean("sample",true)); box.addView(sample);
        repeat=new CheckBox(this); repeat.setText("循环：每次重新看到红色，再变绿再点击"); repeat.setChecked(Prefs.get(this).getBoolean("repeat",false)); box.addView(repeat);
        text(box,"默认只点一次。循环模式每次点击结束后等待 300 ms 再重新找红色，首次点击不受影响。更改参数会暂停监测。",13);
        button(box,"保存设置",()->{
            int selected=scale.getSelectedItemPosition(),nextDiv=selected==1?1:selected==2?4:2;
            boolean rebuild=nextDiv!=Prefs.get(this).getInt("divisor",2);
            CaptureService.pause();
            Prefs.get(this).edit().putInt("divisor",nextDiv).putBoolean("direct",direct.isChecked()).putInt("frames",frames.getSelectedItemPosition()+1).putBoolean("sample",sample.isChecked()).putBoolean("repeat",repeat.isChecked()).apply();
            if(rebuild && CaptureService.instance!=null) { CaptureService.stop(this); toast("已保存；采集尺寸变更，请重新点②授权采集"); }
            else toast("已保存，按悬浮条“开始”生效");
        });
        button(box,"打开红转绿测试页",()->{ CaptureService.pause(); startActivity(new Intent(this,DemoActivity.class)); });
        button(box,"停止并关闭采集",()->{ CaptureService.stop(this); if(TapService.instance!=null) TapService.instance.removePanel(); });
        text(box,"隐私与兼容\n屏幕画面仅在本机内存读取，不保存、不上传；应用没有联网权限。仅支持 Android 8 及以上。Android 14 及以上授权时请选择“整个屏幕”，否则跨应用坐标可能不一致。受保护页面无法采集。旋转屏幕后需重新开启采集并选点。\n\n安装后若系统禁止开启无障碍，请先在系统“应用信息”的菜单里允许受限设置，再返回开启；具体入口因手机品牌而异。",13);
    }
    private String points() { android.content.SharedPreferences p=Prefs.get(this); return "监测点："+p.getInt("mx",-1)+", "+p.getInt("my",-1)+"　点击点："+p.getInt("tx",-1)+", "+p.getInt("ty",-1); }
    private boolean ready() { if(TapService.instance==null) { toast("请先开启“红绿快点”无障碍服务"); return false; } return true; }
    private void requestCapture() {
        if(!ready())return;
        if(CaptureService.instance!=null) { TapService.instance.showPanel(); return; }
        new AlertDialog.Builder(this).setTitle("允许本地识别屏幕颜色")
            .setMessage("将持续读取屏幕图像，仅检测你选定位置的颜色；不会录屏保存或上传。采集期间会显示常驻通知。Android 14 及以上请选择“整个屏幕”。你可以通过通知或悬浮条随时停止。")
            .setPositiveButton("继续授权",(d,w)->{
                if(Build.VERSION.SDK_INT>=33 && checkSelfPermission("android.permission.POST_NOTIFICATIONS")!=android.content.pm.PackageManager.PERMISSION_GRANTED) requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"},41);
                else captureDialog();
            }).setNegativeButton("取消",null).show();
    }
    public void onRequestPermissionsResult(int r,String[] p,int[] grants) { super.onRequestPermissionsResult(r,p,grants); if(r==41)captureDialog(); }
    private void captureDialog() {
        MediaProjectionManager manager=(MediaProjectionManager)getSystemService(MEDIA_PROJECTION_SERVICE);
        Intent request=manager.createScreenCaptureIntent();
        if(Build.VERSION.SDK_INT>=34) {
            try {
                // Public API 34; reflection keeps the build compatible with platform-30.jar.
                Class<?> config=Class.forName("android.media.projection.MediaProjectionConfig");
                Object full=config.getMethod("createConfigForDefaultDisplay").invoke(null);
                request=(Intent)MediaProjectionManager.class.getMethod("createScreenCaptureIntent",config).invoke(manager,full);
            } catch(ReflectiveOperationException ignored) { /* OEM fallback: ask user for entire screen. */ }
        }
        startActivityForResult(request,51);
    }
    protected void onActivityResult(int r,int code,Intent data) { super.onActivityResult(r,code,data); if(r==51 && code==RESULT_OK && data!=null) {
        Intent i=new Intent(this,CaptureService.class).putExtra("code",code).putExtra("token",data);
        startForegroundService(i);
        if(TapService.instance!=null) TapService.instance.showPanel();
        toast("采集已授权；切到目标页面后选点，再按开始");
    }}
    protected void onResume() { super.onResume(); ui.post(refresh); }
    protected void onPause() { ui.removeCallbacks(refresh); super.onPause(); }
    private void title(LinearLayout p,String s,int size) { TextView v=text(p,s,size); v.setTypeface(null,1); }
    private TextView text(LinearLayout p,String s,int size) { TextView v=new TextView(this); v.setText(s); v.setTextSize(size); v.setTextColor(0xff173f3e); v.setPadding(0,10,0,12); p.addView(v); return v; }
    private void button(LinearLayout p,String s,Runnable r) { Button b=new Button(this); b.setText(s); b.setAllCaps(false); p.addView(b,new LinearLayout.LayoutParams(-1,-2)); b.setOnClickListener(v->r.run()); }
    private void toast(String s) { Toast.makeText(this,s,Toast.LENGTH_LONG).show(); }
}
