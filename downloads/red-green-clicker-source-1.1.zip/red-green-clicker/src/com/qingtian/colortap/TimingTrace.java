package com.qingtian.colortap;

/** All timestamps come from System.nanoTime, never from Image's device-specific clock. */
public final class TimingTrace {
    public final long sourceRequestedNs,frameCallbackNs,frameReadyNs,detectedNs;
    public final String profile;
    public volatile long dispatchNs,returnNs,callbackNs,targetDownNs,targetUpNs,targetClickNs;
    public volatile boolean rejected,cancelled;
    public TimingTrace(long source,long callback,long ready,long detected,String profile) {
        sourceRequestedNs=source; frameCallbackNs=callback; frameReadyNs=ready; detectedNs=detected; this.profile=profile;
    }
    public static double millis(long start,long end) { return start>0 && end>=start ? (end-start)/1000000.0 : -1; }
    public double totalMillis() { return millis(sourceRequestedNs,targetClickNs); }
    public double renderAndCaptureMillis() { return millis(sourceRequestedNs,frameReadyNs); }
    public double processingMillis() { return millis(frameReadyNs,detectedNs); }
    public double acquireMillis() { return millis(frameCallbackNs,frameReadyNs); }
    public double queueMillis() { return millis(detectedNs,dispatchNs); }
    public double deliveryMillis() { return millis(dispatchNs,targetClickNs); }
}
