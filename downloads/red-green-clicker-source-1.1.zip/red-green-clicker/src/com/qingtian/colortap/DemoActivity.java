package com.qingtian.colortap;

import android.app.Activity;
import android.os.*;
import android.graphics.Color;
import android.widget.*;
import android.view.*;
import java.util.Locale;
import java.util.concurrent.ThreadLocalRandom;

public class DemoActivity extends Activity {
    private final Handler main=new Handler(Looper.getMainLooper());
    private final LatencyStats stats=new LatencyStats();
    private TextView target,results;
    private int sequence,goal,completed;
    private boolean running,awaitingClick;
    private long trialSourceNs;
    private Runnable timeout;
    private String profile="",lastDetail="";
    private int dp(int n) { return (int)(n*getResources().getDisplayMetrics().density+0.5f); }
    public void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout root=new LinearLayout(this); root.setOrientation(1); root.setPadding(dp(12),dp(16),dp(12),dp(12)); root.setBackgroundColor(0xfff3f7f5); setContentView(root);
        TextView help=new TextView(this);
        help.setText("1.1 · 红转绿实测\n先开启采集并移开悬浮条。测试会把两个坐标设为色块内空白处；期间请勿手动点色块。");
        help.setTextSize(15); help.setTextColor(0xff173f3e); root.addView(help);
        target=new TextView(this); target.setGravity(Gravity.CENTER); target.setText("RED"); target.setTextColor(Color.WHITE); target.setTextSize(27); target.setBackgroundColor(0xffd92f3f);
        LinearLayout.LayoutParams tp=new LinearLayout.LayoutParams(-1,0,1); tp.topMargin=dp(8); tp.bottomMargin=dp(8); root.addView(target,tp);
        ScrollView report=new ScrollView(this); results=new TextView(this); results.setTextSize(13); results.setTextColor(0xff173f3e); report.addView(results); root.addView(report,new LinearLayout.LayoutParams(-1,dp(205)));
        results.setText("点“单次测试”或“连续10次”即可自动选点、等红、变绿和计时。\n\n总耗时沿用 1.0 的口径：提交变色 → 目标收到点击，包含等待渲染和屏幕采集的时间。分段中的“渲染＋采集”无法仅靠本程序进一步分离。\n\n在设置页切换原/半分辨率、直达/兼容模式，再分别测一组。更改分辨率后要重新授权采集。");
        target.setOnTouchListener((v,event)->{
            TimingTrace trace=TraceHub.forDemo(trialSourceNs);
            if(running && awaitingClick && trace!=null) {
                if(event.getActionMasked()==MotionEvent.ACTION_DOWN)trace.targetDownNs=System.nanoTime();
                else if(event.getActionMasked()==MotionEvent.ACTION_UP)trace.targetUpNs=System.nanoTime();
            }
            return false;
        });
        target.setOnClickListener(v->{
            if(!running || !awaitingClick)return;
            TimingTrace trace=TraceHub.forDemo(trialSourceNs);
            if(trace==null || trace.targetDownNs==0 || trace.targetUpNs==0)return;
            trace.targetClickNs=System.nanoTime();
            if(trace.renderAndCaptureMillis()<0 || !stats.add(trace.totalMillis())) { abort("计时未匹配，请重新测试"); return; }
            complete(trace);
        });
        LinearLayout first=new LinearLayout(this); root.addView(first); button(first,"单次测试",()->startSeries(1)); button(first,"连续10次",()->startSeries(10));
        LinearLayout second=new LinearLayout(this); root.addView(second); button(second,"停止测试",()->abort("测试已停止")); button(second,"返回设置",this::finish);
    }
    private void startSeries(int count) {
        if(CaptureService.instance==null || TapService.instance==null) { toast("请先回设置页开启无障碍和屏幕采集"); return; }
        cancel(); stats.reset(); completed=0; goal=count; lastDetail=""; running=true;
        int token=sequence;
        target.post(()->runTrial(token));
    }
    private void runTrial(int token) {
        if(!active(token))return;
        CaptureService capture=CaptureService.instance;
        if(capture==null) { abort("采集已断开，请重新授权"); return; }
        CaptureService.pause(); awaitingClick=false; trialSourceNs=0; TraceHub.demoSourceNs=0;
        target.setBackgroundColor(0xffd92f3f); target.setText("RED");
        render("第 "+(completed+1)+" / "+goal+" 次 · 准备红色画面");
        main.postDelayed(()->{
            if(!active(token))return;
            if(target.getWidth()<10 || target.getHeight()<10) { abort("测试色块尺寸不足"); return; }
            int[] location=new int[2]; target.getLocationOnScreen(location);
            int x=location[0]+target.getWidth()/5,y=location[1]+target.getHeight()*3/4;
            Prefs.point(this,true,x,y); Prefs.point(this,false,x,y);
            CaptureService current=CaptureService.instance;
            if(current==null || !current.beginTest()) { abort(CaptureService.status+"\n请移开悬浮条后重试"); return; }
            profile=current.profile();
            waitForRed(token,SystemClock.uptimeMillis()+2000);
        },250);
    }
    private void waitForRed(int token,long deadline) {
        if(!active(token))return;
        CaptureService capture=CaptureService.instance;
        if(capture==null || !capture.busy()) { abort("监测已暂停，请重新测试"); return; }
        if(capture.isArmed()) {
            // Vary the source-change phase instead of selecting a single favourable vsync.
            main.postDelayed(()->turnGreen(token),ThreadLocalRandom.current().nextInt(120,241)); return;
        }
        if(SystemClock.uptimeMillis()>deadline) { abort("未识别到红色，请检查色块、采集范围和悬浮条位置"); return; }
        main.postDelayed(()->waitForRed(token,deadline),40);
    }
    private void turnGreen(int token) {
        if(!active(token))return;
        awaitingClick=true;
        trialSourceNs=System.nanoTime(); TraceHub.demoSourceNs=trialSourceNs;
        target.setBackgroundColor(0xff14c969); target.setText("GREEN");
        // No result-text redraw in the detection interval.
        timeout=()->{ if(active(token) && awaitingClick)abort("绿色后 3 秒未收到点击，已停止；超时不计入成功样本"); };
        main.postDelayed(timeout,3000);
    }
    private void complete(TimingTrace trace) {
        awaitingClick=false; completed++; TraceHub.demoSourceNs=0;
        if(timeout!=null)main.removeCallbacks(timeout);
        CaptureService.pause();
        lastDetail="最近一次："+ms(trace.totalMillis())+" ms\n"
            +"渲染/采集/等待取帧："+ms(trace.renderAndCaptureMillis())+" ms\n"
            +"　其中取帧API："+ms(trace.acquireMillis())+" ms\n"
            +"采样＋判色："+ms(trace.processingMillis())+" ms\n"
            +"判色→提交点击："+ms(trace.queueMillis())+" ms\n"
            +"提交→目标收到点击："+ms(trace.deliveryMillis())+" ms";
        if(completed>=goal) { running=false; render("本组完成 · "+completed+" / "+goal+" 次成功"); }
        else { render("已收到第 "+completed+" 次点击"); int token=sequence; main.postDelayed(()->runTrial(token),450); }
    }
    private void render(String heading) {
        String summary=stats.count()==0?"尚无成功样本":"中位数 "+ms(stats.median())+" ms　P95 "+ms(stats.p95())+" ms\n最小 "+ms(stats.min())+" ms　最大 "+ms(stats.max())+" ms";
        results.setText(heading+"\n"+profile+"\n"+summary+"\n\n"+lastDetail+"\n\n总计时含等待画面渲染，不等于实际显示到触摸的光学测量。请比较相同模式下多次结果。");
    }
    private boolean active(int token) { return running && sequence==token && !isFinishing(); }
    private void cancel() {
        sequence++; running=false; awaitingClick=false; trialSourceNs=0; TraceHub.demoSourceNs=0;
        main.removeCallbacksAndMessages(null); CaptureService.pause();
    }
    private void abort(String message) { cancel(); if(results!=null)render(message); }
    private String ms(double value) { return value<0?"—":String.format(Locale.US,"%.2f",value); }
    private void toast(String s) { Toast.makeText(this,s,Toast.LENGTH_LONG).show(); }
    private void button(LinearLayout row,String s,Runnable r) { Button b=new Button(this); b.setText(s); b.setTextSize(14); row.addView(b,new LinearLayout.LayoutParams(0,-2,1)); b.setOnClickListener(v->r.run()); }
    protected void onPause() { if(running)abort("离开页面，测试已停止"); TraceHub.demoSourceNs=0; super.onPause(); }
    protected void onDestroy() { cancel(); super.onDestroy(); }
}
