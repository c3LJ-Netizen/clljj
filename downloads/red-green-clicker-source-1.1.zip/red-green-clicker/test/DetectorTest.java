import com.qingtian.colortap.ColorDetector;

public final class DetectorTest {
    static int checks;
    static void check(boolean v,String s) { checks++; if(!v)throw new AssertionError(s); }
    public static void main(String[] args) {
        check(ColorDetector.classify(255,0,0)==ColorDetector.RED,"red");
        check(ColorDetector.classify(220,45,65)==ColorDetector.RED,"pink-red");
        check(ColorDetector.classify(0,255,0)==ColorDetector.GREEN,"green");
        check(ColorDetector.classify(20,201,105)==ColorDetector.GREEN,"demo green");
        check(ColorDetector.classify(217,47,63)==ColorDetector.RED,"demo red");
        check(ColorDetector.classify(255,255,255)==0,"white");
        check(ColorDetector.classify(0,0,255)==0,"blue");
        check(ColorDetector.classify(255,255,0)==0,"yellow");
        check(ColorDetector.classify(60,0,0)==0,"too dark");
        check(ColorDetector.classify(150,145,145)==0,"unsaturated");
        ColorDetector one=new ColorDetector(1);
        for(int i=0;i<100;i++)check(!one.accept(2),"green startup never clicks");
        check(!one.accept(1)&&one.isArmed(),"red arms");
        check(one.accept(2),"first green triggers immediately");
        for(int i=0;i<100;i++)check(!one.accept(i%3),"single-shot cannot double-fire");
        ColorDetector two=new ColorDetector(2);
        check(!two.accept(1),"red"); check(!two.accept(2),"first green waits");
        check(!two.accept(0),"neutral interrupts consecutive greens"); check(!two.accept(2),"new first green"); check(two.accept(2),"second green triggers");
        ColorDetector again=new ColorDetector(1);
        check(!again.accept(2),"repeat needs new red"); check(!again.accept(1),"repeat red arms"); check(again.accept(2),"repeat green triggers");
        ColorDetector fade=new ColorDetector(1); fade.accept(1); fade.accept(0); check(fade.accept(2),"transition can pass through neutral");
        // Exhaust channel boundaries: never throw or misclassify achromatic pixels.
        for(int v=0;v<256;v++)check(ColorDetector.classify(v,v,v)==0,"grayscale "+v);
        System.out.println("PASS: "+checks+" color/state checks");
    }
}
