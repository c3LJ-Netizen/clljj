import com.qingtian.colortap.*;
import java.nio.ByteBuffer;

public final class OptimizationTest {
    private static int checks;
    private static void check(boolean b,String s) { checks++; if(!b)throw new AssertionError(s); }
    private static void close(double a,double b,String s) { check(Math.abs(a-b)<0.000001,s+": "+a+" != "+b); }
    private static void put(ByteBuffer b,int row,int pixel,int x,int y,int rgb) {
        int at=y*row+x*pixel; b.put(at,(byte)(rgb>>16)); b.put(at+1,(byte)(rgb>>8)); b.put(at+2,(byte)rgb);
    }
    public static void main(String[] args) {
        check(PixelSampler.divisor(1080,2400,2)==2,"half-size exact aspect");
        check(PixelSampler.divisor(1220,2712,4)==4,"quarter-size exact aspect");
        check(PixelSampler.divisor(1082,2400,4)==2,"quarter falls back to half");
        check(PixelSampler.divisor(1081,2400,2)==1,"odd display preserves exact aspect");
        for(int extent:new int[]{1,2,8,1080,1220,1440,2400,2712}) {
            for(int requested:new int[]{1,2,4}) {
                int divisor=PixelSampler.divisor(extent,extent,requested),capture=extent/divisor,previous=-1;
                for(int point=0;point<extent;point++) {
                    int mapped=PixelSampler.map(point,extent,capture);
                    check(mapped>=0 && mapped<capture,"mapped point in bounds");
                    check(mapped>=previous,"monotonic mapping");
                    check(mapped==point/divisor,"correct scaled cell");
                    previous=mapped;
                }
                check(PixelSampler.map(0,extent,capture)==0,"first pixel");
                check(PixelSampler.map(extent-1,extent,capture)==capture-1,"last pixel");
            }
        }
        ByteBuffer padded=ByteBuffer.allocateDirect(3*32-5);
        for(int y=0;y<3;y++)for(int x=0;x<3;x++)put(padded,32,8,x,y,0xff0000);
        check(PixelSampler.rgb(padded,3,3,32,8,1,1,1)==0xff0000,"padded rows, stride 8");
        check(PixelSampler.rgb(padded,3,3,32,8,2,2,1)==0xff0000,"edge radius clipped");
        put(padded,32,8,1,1,0x00ff00);
        check(PixelSampler.rgb(padded,3,3,32,8,1,1,0)==0x00ff00,"single pixel");
        check(PixelSampler.rgb(padded,3,3,32,8,1,1,1)==0xe21c00,"average channels");
        check(padded.position()==0,"does not mutate buffer position");
        padded.limit(80);
        check(PixelSampler.rgb(padded,3,3,32,8,2,2,0)==-1,"truncated buffer safely rejected");
        check(PixelSampler.rgb(padded,3,3,8,4,0,0,0)==-1,"invalid row stride");
        check(PixelSampler.rgb(padded,3,3,32,2,0,0,0)==-1,"invalid pixel stride");
        check(PixelSampler.rgb(padded,3,3,32,8,-1,0,0)==-1,"negative coordinate");
        check(PixelSampler.rgb(null,3,3,32,8,0,0,0)==-1,"missing buffer");
        ByteBuffer lastRow=ByteBuffer.allocate(4*8+4+3); // buffer ends after final pixel's RGB, no alpha/padding
        for(int y=0;y<5;y++)for(int x=0;x<2;x++)put(lastRow,8,4,x,y,0x00ff00);
        check(PixelSampler.rgb(lastRow,2,5,8,4,1,4,1)==0x00ff00,"last-row padding not required");
        // Full, half and quarter capture feed the same red-to-green state machine.
        for(int div:new int[]{1,2,4}) {
            int cw=24/div,ch=40/div,row=cw*4+16;
            ByteBuffer pixels=ByteBuffer.allocate(row*ch);
            int x=PixelSampler.map(23,24,cw),y=PixelSampler.map(39,40,ch);
            ColorDetector d=new ColorDetector(1);
            int index=0;
            for(int color:new int[]{0x00ff00,0xff0000,0x00ff00,0x00ff00}) {
                for(int yy=0;yy<ch;yy++)for(int xx=0;xx<cw;xx++)put(pixels,row,4,xx,yy,color);
                int rgb=PixelSampler.rgb(pixels,cw,ch,row,4,x,y,1);
                boolean fired=d.accept(ColorDetector.classify(rgb>>16,(rgb>>8)&255,rgb&255));
                check(fired==(index++==2),"exactly one scaled transition trigger");
                if(color==0xff0000)check(!fired&&d.isArmed(),"scaled red arms");
                else if(!d.isArmed())check(!fired,"scaled green startup ignored");
                else if(fired)check(d.isArmed(),"scaled green fires");
            }
            check(!d.accept(ColorDetector.GREEN),"scaled single shot");
        }
        LatencyStats stats=new LatencyStats();
        check(stats.median()==-1,"no samples");
        check(!stats.add(-1)&&!stats.add(Double.NaN)&&!stats.add(Double.POSITIVE_INFINITY),"reject invalid timings");
        for(double n:new double[]{90,30,50,70})stats.add(n);
        close(stats.min(),30,"minimum"); close(stats.median(),60,"even median"); close(stats.p95(),90,"nearest rank P95"); close(stats.max(),90,"maximum");
        stats.add(100); close(stats.median(),70,"odd median");
        stats.reset(); for(int i=1;i<=100;i++)check(stats.add(i),"keep all 100 samples");
        check(!stats.add(101),"bounded series"); close(stats.p95(),95,"P95 with 100 values");
        long source=1000000000L;
        TimingTrace trace=new TimingTrace(source,source+39000000,source+40000000,source+41000000,"50% direct");
        trace.dispatchNs=source+42000000; trace.targetClickNs=source+90000000;
        close(trace.totalMillis(),90,"total unchanged measurement origin");
        close(trace.acquireMillis(),1,"acquire time measured separately without double-counting");
        close(trace.renderAndCaptureMillis()+trace.processingMillis()+trace.queueMillis()+trace.deliveryMillis(),trace.totalMillis(),"segments sum to actual total");
        check(TimingTrace.millis(0,100)==-1 && TimingTrace.millis(100,99)==-1,"invalid time origins");
        TimingTrace concurrent=new TimingTrace(source,source-1000000,source+1000000,source+2000000,"frame arrived during acquire");
        close(concurrent.renderAndCaptureMillis(),1,"callback may precede source; ready timestamp remains valid");
        TraceHub.latest=trace;
        check(TraceHub.forDemo(source)==trace,"matching submitted automatic click");
        check(TraceHub.forDemo(source+1)==null,"stale trial rejected");
        trace.cancelled=true; check(TraceHub.forDemo(source)==null,"cancelled tap rejected");
        trace.cancelled=false; trace.rejected=true; check(TraceHub.forDemo(source)==null,"rejected tap ignored");
        System.out.println("PASS: "+checks+" scaling, pixel-buffer, latency and benchmark checks");
    }
}
